window.NeedlePOP = {};

NeedlePOP.Views = {};
NeedlePOP.Collections = {};
NeedlePOP.Models = {};
NeedlePOP.Routers = {};

window.app = {};
window.routers = {};
window.plugs = {};
window.views = {};
window.collections = {};