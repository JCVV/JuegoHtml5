$(document).on('ready', inicio);

function inicio()
{
	initGame();
}